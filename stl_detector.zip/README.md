# STL Object Detection System

Industrial-ready object detection system that trains on 3D STL models and runs real-time detection with RealSense D435i camera.

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Train a model (if not already done)
python main.py generate --stl bottle.stl --num-images 500
python main.py train --epochs 50

# Run detection
python main.py detect --camera 0
```

## Industrial Deployment

### Using Launcher Script (Recommended)
```bash
./run_detector.sh
```
Features:
- Auto-restart on crash (up to 10 retries)
- Graceful shutdown on SIGTERM/SIGINT
- Logging to `logs/launcher.log`

### Install as Package
```bash
pip install -e .
stl-detect detect --camera 0
```

## Detection Controls

| Key | Action |
|-----|--------|
| `q` | Quit |
| `s` | Save frame |
| `+` / `=` | Increase confidence |
| `-` | Decrease confidence |

## Configuration

Edit `config.py` to adjust:

| Parameter | Default | Description |
|-----------|---------|-------------|
| `CONFIDENCE_THRESHOLD` | 0.5 | Detection sensitivity |
| `PROXIMITY_THRESHOLD` | 0.4 | Warning distance (meters) |
| `REALSENSE_WIDTH/HEIGHT` | 640x480 | Camera resolution |
| `DEPTH_MAX` | 10.0 | Max detection distance (m) |

## Logs

Logs are stored in `logs/` directory:
- `detector.log` - System events (rotating, max 10MB)
- `detections.log` - Detection events with coordinates
- `launcher.log` - Launcher script events

## Troubleshooting

### Camera not detected
```bash
# Add user to video group
sudo usermod -a -G video $USER
# Log out and log back in
```

### RealSense not available
```bash
# Install RealSense SDK
pip install pyrealsense2
```

### Model not found
```bash
# Train a new model first
python main.py full --stl your_object.stl --epochs 50
```

## Project Structure

```
STL/
├── main.py              # CLI entry point
├── realtime_detector.py # Detection engine
├── config.py            # Configuration
├── logger.py            # Logging system
├── run_detector.sh      # Launcher script
├── setup.py             # Package installer
├── runs/detect/         # Trained models
├── logs/                # Log files
└── detections/          # Saved frames
```
